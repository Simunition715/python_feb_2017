# import Flask
from flask import *
from mysqlconnection import MySQLConnector
# the "re" module will let us perform some regular expression operations
import re
# create a regular expression object that we can use run operations on
EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')
app = Flask(__name__)
mysql = MySQLConnector(app,'emailsdb')
app.secret_key = "ThisIsSecret!"

@app.route('/')
def index():
	query = "SELECT * FROM emails"
	emails = mysql.query_db(query)
	data = {
		'emails':emails
	}
	return render_template('index.html', data=data)




@app.route('/process', methods=['POST'])
def create_email():
	query = "INSERT INTO emails(email , created_at, updated_at) VALUES (:email, NOW(), NOW())"
	values = {
		'email': request.form['email']
	}
	if len(request.form['email']) < 1:
		flash("Name cannot be empty!")
	else:
		flash("Success! Your name is {}".format(request.form['email']))
	mysql.query_db(query,values)
	return redirect('/')

@app.route('/delete/<id>')
def delete(id):
	query = "DELETE FROM emails WHERE id = :id"
	data = {'id': id}
	mysql.query_db(query, data)
	return redirect('/')	




app.run(debug=True)
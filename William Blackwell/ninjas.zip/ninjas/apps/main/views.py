from django.shortcuts import render
def index(request):
	
	return render(request, "main/index.html")
def ninjas(request):

	return render(request,"main/ninjas.html")	

def colors(request,color):
	print color
	print "*"*50
	if color == 'blue':
		img_path = '../../static/main/img/leonardo.jpg'
	elif color == 'red':
		img_path = '../../static/main/img/raphael.jpg'
	elif color == 'orange':
		img_path = '../../static/main/img/michelangelo.jpg'
	elif color == 'purple':
		img_path = '../../static/main/img/donatello.jpg'
	else:
		img_path = '../../static/main/img/notapril.jpg'			
	colors = {
		'img_path': img_path,
	}
	return render(request,"main/colors.html",colors)

# Create your views here.

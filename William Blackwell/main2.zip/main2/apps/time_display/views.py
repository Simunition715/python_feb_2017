from django.shortcuts import render
import datetime


def index(request):
	
	return render(request, "time_display/index.html")
# Create your views here.


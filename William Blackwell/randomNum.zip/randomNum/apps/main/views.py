from django.shortcuts import render, redirect
import string
import random

def index(request):
	if request.method == 'POST':
		print "*"*50
		request.session['word'] =''.join(random.choice(string.lowercase + string.digits) for i in range(14))
		request.session['name'] = request.session['name'] + 1
	if request.method =='GET':
		request.session['name'] = 0	

	return render(request,"main/index.html")






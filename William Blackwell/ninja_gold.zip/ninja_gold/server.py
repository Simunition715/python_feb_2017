from flask import Flask, render_template, session, redirect, request
import random



app = Flask(__name__)
app.secret_key="kjlkdj"
@app.route('/')
def index():
	if "gold" not in session:
		session['gold']=0
	return render_template("index.html")
	

@app.route('/coins', methods =['POST'])
def coins():
	if request.form['farm']:
		session['gold'] = session['gold']+random.randrange(10,20)
		return redirect('/')
@app.route('/coins1', methods =['POST'])
def coins1():		
	if request.form['cave']:
		session['gold'] = session['gold']+random.randrange(5,10)
		return redirect('/')
@app.route('/coins2', methods =['POST'])
def coins2():		
	if request.form['house']:
		session['gold'] = session['gold']+random.randrange(2,5)
		return redirect('/')
@app.route('/coins3', methods =['POST'])
def coins3():		
	if request.form['casino']:
		session['gold'] = session['gold']+random.randrange(-50,50)	
		return redirect("/")

@app.route('/reset', methods =['POST'])
def reset():		
	if request.form['reset']:
		session['gold'] = 0
		return redirect("/")





app.run(debug=True)

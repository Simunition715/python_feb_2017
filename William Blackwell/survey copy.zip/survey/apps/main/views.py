from django.shortcuts import render,redirect

def index(request):
	
	return render(request, "main/index.html")

def survey(request):
	request.session['name']= request.POST['first_name']
	request.session['location']= request.POST['location']
	request.session['language']= request.POST['language']
	
	return render(request, "main/survey.html")	
	



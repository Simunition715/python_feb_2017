from django.conf.urls import url
from . import views
# CONTROLLER!!!!

urlpatterns = [
	url(r'^$', views.index),
	url(r'^survey$',views.survey)

]
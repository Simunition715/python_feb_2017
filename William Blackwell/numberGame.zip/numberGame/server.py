from flask import Flask, render_template, session, request, redirect
app = Flask(__name__)
app.secret_key="ughhhhhhhhhhh"
import random

def randomnum():
	import random

	if 'random' not in session:
		random_num=random.randrange(0,101)
		session['random']=random_num
	else:
		return

@app.route('/')
def count():
	if not 'random' in session:
		random_num=random.randrange(0,101)
		session['random']=random_num
	#print session['random']

	#print 'working'
	return render_template('index.html')

@app.route('/', methods=['POST'])
def checker():
	odds = int(request.form['guess'])
	session['Win']=''
	print session['win']
	if odds==session['random']:
		print 'Winner winner chicken dinner!'
		session['win']='winner'
	elif guess > session['random']:
		print 'Too high!'
		session['win']='Too High'
	elif guess < session[random]:
		print 'Too Low!'
		session['win']='Too Low'
	return redirect('/')	


@app.route('/reset')
def reset():
	session.clear()
	return redirect('/')



app.run(debug=True)

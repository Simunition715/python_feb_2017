from flask import Flask, render_template, request, session, redirect
app = Flask(__name__)
app.secret_key="allknowing"


@app.route('/')
def index():
	return render_template("index.html")	



@app.route('/results')
def submit():

	return render_template("results.html")	



@app.route('/submit', methods=['POST'])
def usersubmit():	
	session['name'] = request.form['alias']
	session['location'] = request.form['location']
	session['language'] = request.form['language']
	session['comments'] = request.form['comments']	

	return render_template("results.html") 






app.run(debug=True)

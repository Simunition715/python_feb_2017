from flask import *
from mysqlconnection import MySQLConnector
from flask_bcrypt import Bcrypt
import re

EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')
app = Flask(__name__)
bcrypt = Bcrypt(app)
mysql = MySQLConnector(app, 'wall')
app.secret_key = "ThisIsSecret"

@app.route('/')
def index():
		return render_template("index.html")


@app.route('/users', methods=['POST'])
def create_user():
	if request.form['password'] != request.form['password_confirmation']:
		flash('Your passwords do not match!')
		return redirect('/')
	query = "INSERT INTO users (first_name,last_name,password,created_at,updated_at) VALUES (:first_name,:last_name,:password, NOW(), NOW())"
	values = {
		'first_name': request.form['first_name'],
		'last_name': request.form['last_name'],
		'password':bcrypt.generate_password_hash(request.form['password']),
	}
	user_id = mysql.query_db(query,values)
	session['user_id'] = user_id

	return redirect('/success')

@app.route('/success')
def success():
	query = "SELECT * FROM messages"
	messages = mysql.query_db(query)

	return render_template('/success.html', messages=messages)	

@app.route('/sessions', methods=['POST'])
def login_user():
	query = "SELECT * FROM users WHERE first_name = :first_name;"
	values = {
	'first_name': request.form['first_name']
	}
	user = mysql.query_db(query,values)
	if len(user) != 0 and bcrypt.check_password_hash(user[0]['password'], request.form['password']):
		session['user_id'] = user[0]['id']
		return redirect('/success')
	else:
		flash('Invalid email or password')
		return redirect('/')

@app.route('/postmsg', methods=['POST'])
def create_post():
	query = "INSERT INTO messages(message,created_at, updated_at,user_id) VALUES(:message, NOW(),NOW(),:user_id)"
	values = {
		'message':request.form['message'],
		'user_id':session['user_id']
	}
	mysql.query_db(query,values)
	return redirect('/success')






app.run(debug=True)
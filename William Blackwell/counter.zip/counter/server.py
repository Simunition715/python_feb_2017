from flask import Flask, render_template, session,request,redirect

app = Flask(__name__)
app.secret_key="blah"

def session_counter():
	x = session['counter']
	if 'counter' not in session:
	  x = 0
	else:
	  x += 1  
    
	print x

@app.route('/',methods=['GET'])
def index():
  return render_template("index.html")




app.run(debug=True)